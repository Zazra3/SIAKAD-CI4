<?php

namespace App\Controllers;

use App\Models\MahasiswaModel;

class Mahasiswa extends BaseController
{
    public function index()
    {
        $model = new MahasiswaModel();

        return view('mahasiswa/index', [
            'mahasiswa' => $model->findAll()
        ]);
    }

    public function detail($id)
    {
        $model = new MahasiswaModel();

        return view('mahasiswa/detail', [
            'mhs' => $model->where('nim', $id)->first()
        ]);
    }
}