<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<style>
.page-title{
    font-weight:800;
    font-size:22px;
}

.card-box{
    border:none;
    border-radius:16px;
    box-shadow:0 8px 18px rgba(0,0,0,.05);
}

.stat-mini{
    padding:14px;
    border-radius:14px;
    background:#f8fafc;
}

.table-hover tbody tr{
    cursor:pointer;
    transition:.2s;
}

.table-hover tbody tr:hover{
    background:#eef2ff;
    transform:scale(1.01);
}

.badge-status{
    border-radius:10px;
    padding:6px 10px;
}
</style>

<div class="container-fluid">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <div class="page-title">Total Mahasiswa</div>
            <small class="text-muted">Data seluruh mahasiswa aktif & nonaktif</small>
        </div>
    </div>

    <!-- STAT -->
    <div class="row g-3 mb-3">

        <div class="col-md-3">
            <div class="card card-box">
                <div class="card-body">
                    <div class="text-muted">Total</div>
                    <h4>1.250</h4>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card card-box">
                <div class="card-body">
                    <div class="text-muted">Aktif</div>
                    <h4 class="text-success">1.120</h4>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card card-box">
                <div class="card-body">
                    <div class="text-muted">Nonaktif</div>
                    <h4 class="text-danger">130</h4>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card card-box">
                <div class="card-body">
                    <div class="text-muted">Prodi</div>
                    <h4>2</h4>
                </div>
            </div>
        </div>

    </div>

    <!-- FILTER -->
    <div class="card card-box mb-3">
        <div class="card-body d-flex gap-2">

            <input type="text" class="form-control" placeholder="Cari nama / NIM...">

            <select class="form-control" style="max-width:200px">
                <option>Semua Prodi</option>
                <option>Teknik Informatika</option>
                <option>Sistem Informasi</option>
            </select>

        </div>
    </div>

    <!-- TABLE -->
    <div class="card card-box">
        <div class="card-body">

            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>NIM</th>
                        <th>Nama</th>
                        <th>Prodi</th>
                        <th>Semester</th>
                        <th>Status</th>
                    </tr>
                </thead>

                <tbody>

                    <?php foreach($mahasiswa as $m): ?>
                    <tr onclick="window.location='<?= base_url('mahasiswa/detail/'.$m['nim']) ?>'">

                        <td><?= $m['nim'] ?></td>
                        <td><?= $m['nama'] ?></td>
                        <td><?= $m['prodi'] ?></td>
                        <td><?= $m['semester'] ?></td>

                        <td>
                            <?php if($m['status'] == 'Aktif'): ?>
                                <span class="badge bg-success badge-status">Aktif</span>
                            <?php else: ?>
                                <span class="badge bg-danger badge-status">Nonaktif</span>
                            <?php endif; ?>
                        </td>

                    </tr>
                    <?php endforeach; ?>

                </tbody>
            </table>

        </div>
    </div>

</div>

<?= $this->endSection() ?>