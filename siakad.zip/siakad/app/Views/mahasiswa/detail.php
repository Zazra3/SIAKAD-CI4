<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<div class="card shadow-sm border-0 rounded-4">
    <div class="card-body p-4">

        <h4 class="fw-bold">Detail Mahasiswa</h4>
        <hr>

        <p><b>NIM:</b> <?= $mhs['nim'] ?></p>
        <p><b>Nama:</b> <?= $mhs['nama'] ?></p>
        <p><b>Prodi:</b> <?= $mhs['prodi'] ?></p>
        <p><b>Semester:</b> <?= $mhs['semester'] ?></p>
        <p><b>Status:</b> <?= $mhs['status'] ?></p>

        <a href="<?= base_url('mahasiswa') ?>" class="btn btn-primary mt-3">
            Kembali
        </a>

    </div>
</div>

<?= $this->endSection() ?>