<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SIAKAD Mahasiswa</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        body{
            background:#f4f6f9;
            font-family:'Segoe UI',sans-serif;
        }

        /* ===== NAVBAR MODERN ===== */
        .navbar-custom{
            background: rgba(255,255,255,0.85);
            backdrop-filter: blur(12px);
            -webkit-backdrop-filter: blur(12px);

            box-shadow: 0 10px 30px rgba(0,0,0,.08);
            border-bottom: 1px solid rgba(99,102,241,.15);

            padding: 18px 25px;   /* 🔥 bikin lebih tinggi */
            min-height: 80px;    /* 🔥 efek “panjang ke bawah” */
        }

        .navbar-brand{
            font-weight:800;
            letter-spacing:1px;
            font-size:20px;
        }

        .nav-link{
            display:flex;
            align-items:center;
            gap:8px;
            padding:10px 14px;
            border-radius:12px;
            transition:.25s;
            font-weight:500;
            color:#334155 !important;
        }

        .nav-link:hover{
            background: linear-gradient(135deg,#6366f1,#8b5cf6);
            color:white !important;
            transform: translateY(-1px);
            box-shadow:0 6px 15px rgba(99,102,241,.25);
        }

        /* ACTIVE LOOK (optional nanti bisa dipakai CI4) */
        .nav-link.active{
            background:#6366f1;
            color:white !important;
        }

        /* USER BUTTON */
        .dropdown .btn{
            border-radius:50px;
            padding:8px 16px;
            background:white;
            border:1px solid #e2e8f0;
            box-shadow:0 5px 15px rgba(0,0,0,.05);
        }

        .dropdown .btn:hover{
            transform: translateY(-1px);
        }

        .main-content{
            padding:25px;
        }

        @media(max-width:768px){
            .navbar-custom{
                min-height:auto;
                padding:14px 15px;
            }
        }
    </style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-custom">
    <div class="container-fluid">

        <!-- BRAND -->
        <a class="navbar-brand" href="<?= base_url('/') ?>">
            SIAKAD
        </a>

        <!-- MOBILE TOGGLER -->
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#menuSidebar">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- MENU -->
        <div class="collapse navbar-collapse justify-content-between">

            <ul class="navbar-nav gap-1">

                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('/') ?>">
                        <i class="bi bi-grid-fill"></i> Dashboard
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('mahasiswa') ?>">
                        <i class="bi bi-people-fill"></i> Mahasiswa
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('mahasiswa/create') ?>">
                        <i class="bi bi-person-plus-fill"></i> Tambah
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <i class="bi bi-journal-bookmark-fill"></i> Prodi
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="#">
                        <i class="bi bi-bar-chart-fill"></i> Laporan
                    </a>
                </li>

            </ul>

            <!-- USER -->
            <div class="dropdown">
                <button class="btn dropdown-toggle" data-bs-toggle="dropdown">
                    <i class="bi bi-person-circle"></i> Admin
                </button>

                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="#">Profil</a></li>
                    <li><a class="dropdown-item text-danger" href="<?= base_url('logout') ?>">Logout</a></li>
                </ul>
            </div>

        </div>
    </div>
</nav>

<!-- CONTENT -->
<div class="main-content">
    <?= $this->renderSection('content') ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>