<?= $this->extend('layout/main') ?>
<?= $this->section('content') ?>

<style>

/* ===== GLOBAL ===== */
.page-header{ margin-bottom:18px; }

.hero{
    position:relative;
    overflow:hidden;
    border-radius:26px;
    padding:26px;
    color:white;
    background: linear-gradient(135deg,#2563eb,#7c3aed);
    box-shadow:0 18px 45px rgba(37,99,235,.2);
}

/* ===== CLICKABLE EFFECT ===== */
.clickable{
    cursor:pointer;
    transition:.2s;
    text-decoration:none;
    color:inherit;
}
.clickable:hover{
    transform:translateY(-4px);
}

/* ===== CARD KPI ===== */
.stat-card{
    border:none;
    border-radius:18px;
    background:white;
    box-shadow:0 8px 18px rgba(0,0,0,.04);
}

.stat-card:hover{
    box-shadow:0 14px 30px rgba(0,0,0,.08);
}

.stat-icon{
    width:46px;
    height:46px;
    border-radius:14px;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:20px;
}

.stat-number{
    font-size:26px;
    font-weight:800;
}

/* ===== QUICK ===== */
.quick-card{
    text-decoration:none;
    background:white;
    border-radius:18px;
    padding:16px;
    color:#111827;
    display:block;
    transition:.2s;
    box-shadow:0 6px 16px rgba(0,0,0,.04);
    font-size:14px;
    cursor:pointer;
}

.quick-card:hover{
    transform:translateY(-4px);
    color:white;
    background:linear-gradient(135deg,#2563eb,#7c3aed);
}

/* ===== PANEL ===== */
.panel{
    border:none;
    border-radius:18px;
    background:white;
    box-shadow:0 8px 18px rgba(0,0,0,.04);
}

/* ===== TABLE CLICK ===== */
.table-modern tbody tr{
    cursor:pointer;
    transition:.2s;
}

.table-modern tbody tr:hover{
    background:#f8fafc;
    transform:scale(1.01);
}

.table-modern{
    border-collapse:separate;
    border-spacing:0 6px;
    font-size:14px;
}

.table-modern td{
    padding:12px;
    border:none;
}

.table-modern th{
    border:none;
    padding:10px;
}

</style>

<!-- HERO -->
<div class="page-header">
    <div class="hero">
        <div class="row align-items-center">
            <div class="col-lg-8">
                <small>SISTEM INFORMASI AKADEMIK</small>
                <h3 class="fw-bold mt-2">Dashboard Akademik</h3>
                <p class="mb-0" style="opacity:.9;font-size:14px">
                    Monitoring data mahasiswa dan prodi secara realtime.
                </p>
            </div>
            <div class="col-lg-4 text-end">
                <h1 class="fw-bold">2026</h1>
            </div>
        </div>
    </div>
</div>

<!-- KPI (CLICKABLE) -->
<div class="row g-3 mb-3">

    <div class="col-md-4">
        <a href="<?= base_url('mahasiswa') ?>" class="clickable">
            <div class="card stat-card">
                <div class="card-body p-3 d-flex justify-content-between align-items-center">
                    <div>
                        <small class="text-muted">Total Mahasiswa</small>
                        <div class="stat-number">1.250</div>
                    </div>
                    <div class="stat-icon bg-primary-subtle text-primary">
                        <i class="bi bi-people-fill"></i>
                    </div>
                </div>
            </div>
        </a>
    </div>

    <div class="col-md-4">
        <a href="<?= base_url('prodi') ?>" class="clickable">
            <div class="card stat-card">
                <div class="card-body p-3 d-flex justify-content-between align-items-center">
                    <div>
                        <small class="text-muted">Total Prodi</small>
                        <div class="stat-number">2</div>
                    </div>
                    <div class="stat-icon bg-success-subtle text-success">
                        <i class="bi bi-book-fill"></i>
                    </div>
                </div>
            </div>
        </a>
    </div>

    <div class="col-md-4">
        <a href="<?= base_url('dosen') ?>" class="clickable">
            <div class="card stat-card">
                <div class="card-body p-3 d-flex justify-content-between align-items-center">
                    <div>
                        <small class="text-muted">Dosen</small>
                        <div class="stat-number">20</div>
                    </div>
                    <div class="stat-icon bg-warning-subtle text-warning">
                        <i class="bi bi-person-badge-fill"></i>
                    </div>
                </div>
            </div>
        </a>
    </div>

</div>

<!-- PRODI (CLICKABLE) -->
<div class="row g-3 mb-3">

    <div class="col-md-6">
        <a href="<?= base_url('prodi/detail/ti') ?>" class="clickable">
            <div class="card stat-card">
                <div class="card-body p-3 d-flex justify-content-between align-items-center">
                    <div>
                        <small class="text-muted">Teknik Informatika</small>
                        <div class="stat-number">680</div>
                        <small class="text-success">+8% naik</small>
                    </div>
                    <div class="stat-icon bg-primary-subtle text-primary">
                        <i class="bi bi-cpu-fill"></i>
                    </div>
                </div>
            </div>
        </a>
    </div>

    <div class="col-md-6">
        <a href="<?= base_url('prodi/detail/si') ?>" class="clickable">
            <div class="card stat-card">
                <div class="card-body p-3 d-flex justify-content-between align-items-center">
                    <div>
                        <small class="text-muted">Sistem Informasi</small>
                        <div class="stat-number">570</div>
                        <small class="text-success">+5% naik</small>
                    </div>
                    <div class="stat-icon bg-success-subtle text-success">
                        <i class="bi bi-diagram-3-fill"></i>
                    </div>
                </div>
            </div>
        </a>
    </div>

</div>

<!-- QUICK ACTION -->
<div class="row g-3 mb-3">

    <div class="col-md-3">
        <a href="<?= base_url('mahasiswa/create') ?>" class="quick-card">
            <i class="bi bi-person-plus-fill"></i><br>
            Tambah Mahasiswa
        </a>
    </div>

    <div class="col-md-3">
        <a href="<?= base_url('mahasiswa') ?>" class="quick-card">
            <i class="bi bi-table"></i><br>
            Data Mahasiswa
        </a>
    </div>

    <div class="col-md-3">
        <a href="<?= base_url('laporan') ?>" class="quick-card">
            <i class="bi bi-file-earmark-bar-graph-fill"></i><br>
            Laporan
        </a>
    </div>

    <div class="col-md-3">
        <a href="<?= base_url('settings') ?>" class="quick-card">
            <i class="bi bi-gear-fill"></i><br>
            Pengaturan
        </a>
    </div>

</div>

<!-- TABLE CLICKABLE -->
<div class="card panel">
    <div class="card-body p-3">

        <div class="d-flex justify-content-between mb-3">
            <h6 class="fw-bold mb-0">Mahasiswa Terbaru</h6>
            <input class="form-control w-auto" placeholder="Cari...">
        </div>

        <table class="table table-modern">
            <thead>
                <tr>
                    <th>NIM</th>
                    <th>Nama</th>
                    <th>Prodi</th>
                    <th>Semester</th>
                    <th>Status</th>
                </tr>
            </thead>

            <tbody>
                <tr onclick="window.location='<?= base_url('mahasiswa/detail/2301001') ?>'">
                    <td>2301001</td>
                    <td>Andi Saputra</td>
                    <td>Teknik Informatika</td>
                    <td>4</td>
                    <td><span class="badge bg-success">Aktif</span></td>
                </tr>

                <tr onclick="window.location='<?= base_url('mahasiswa/detail/2301002') ?>'">
                    <td>2301002</td>
                    <td>Siti Nurhaliza</td>
                    <td>Sistem Informasi</td>
                    <td>2</td>
                    <td><span class="badge bg-success">Aktif</span></td>
                </tr>
            </tbody>
        </table>

    </div>
</div>

<?= $this->endSection() ?>